extends Node2D

@export var camera: Camera2D
@export var y_offset: float = 0.0
@export var smooth_follow: bool = false
@export var follow_speed: float = 10.0

func _process(delta: float) -> void:
	if camera == null:
		return
	
	var target_y := camera.get_screen_center_position().y + y_offset
	
	if smooth_follow:
		global_position.y = lerp(global_position.y, target_y, follow_speed * delta)
	else:
		global_position.y = target_y
