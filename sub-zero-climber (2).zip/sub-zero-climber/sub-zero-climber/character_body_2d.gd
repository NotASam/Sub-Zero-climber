extends CharacterBody2D


const SPEED = 150.0
const JUMP_VELOCITY = -300.0

@onready var animated_sprite = $AnimatedSprite2D

func _physics_process(delta: float) -> void:

	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction_x := Input.get_axis("left", "right")
	
	if direction_x != 0:
		velocity.x = direction_x * SPEED
		if direction_x > 0:
			animated_sprite.play("1")
		else:
			animated_sprite.play("2")
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	if direction_x == 0:
		animated_sprite.play("Idle")
		
	move_and_slide()
	
